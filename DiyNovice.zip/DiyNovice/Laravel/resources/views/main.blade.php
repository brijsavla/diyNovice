<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<style>

.responsive {
background-repeat:no-repeat;
background-position: auto;
display:block;
margin:0px auto; 
}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

.topnav a {
  display: inline-block;
  color: black;
  text-align: center;
  padding: 14px;
  text-decoration: none;
  font-size: 17px;
  border-radius: 5px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #254117;
  color: white;
}
.div1 {
  width: 200px;
  height: 100px;  
  padding: 40px;
  border: 1px solid black;
  
}
.div2 {
  width: 200px;
  height: 150px;  
  padding: 40px;
  border: 1px solid black;
}
.div3 {
  width: 200px;
  height: 150px;  
  padding: 40px;
  border: 1px solid black;
}

.test1 {
  white-space: nowrap; 
  width: 320px; 
  border: 1px solid #000000;
  overflow: hidden;
  padding: 10px;
  text-overflow: clip;
}

.test2 {
  white-space: nowrap; 
  width: 320px; 
  border: 1px solid #000000;
  overflow: hidden;
  padding: 10px;
  text-overflow: clip;
}

.row {
  display: -ms-flexbox; /* IE 10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE 10 */
  flex-wrap: wrap;
  padding: 0 4px;
}
.column {
  -ms-flex: 50%; /* IE 10 */
  flex: 50%;
  padding: 0 4px;
}

.column img {
  margin-top: 8px;
  vertical-align: middle;
}
 .img-banner
 {
   width:100%;
   background-image:url({{asset("images/IMG_6960.jpg")}});
   height: 200px;
   background-size: 100% 100%;
 }


</style>
</head>
<body>

<div class="img-banner responsive"></div>

<div class="container topnav">
  <div class="navbar-nva">
      <a class="active" href="#Visit">Visit:BoutIt.comTM</a>
      <a href="#Renovation">Renovation Estimator</a>
      <a href="#Account">Account Information</a>
      <a href="#OtherFeatured">Other Featured Resourses</a>
      <a href="{{url('/login')}}">Log In</a>
  </div>
</div>

<div style="padding-center:16px"> </div><br>

<div class="div1"> This Box is reseverd for Sponsor/Advertiser
                   and/orEstimator Supplier banner ads/ Promotions.
</div>  
         
<br><div class="div2"> This box is reserved for site/network announcements,
                   site/network promotions, product promotions and/or
                   "other" information that the company wants to get the
                   word out on etc. etc..
</div>            
      
<p class="test2 ">  Special "Level Up" Planner Series Covers: </p> 
 
<p class="test1">  Books and Resources by: Will G. LoudenTM </p> 
          
<div class="div3"> The above, short abbreviated, book description goes here in this
                   box. IF designed a certain way then the resource could provide a 
                   link to a more informed and detailed resource description on another 
                   page and/or through a pop up box?!! 
</div>

<div class="row-centered"> 
  <div class="column">
    <img src="40-21st-Century-Smart-Home-PTE.jpg" style="width:10%">
    <img src="2-Renovation-Series-Back-Cover.jpg" style="width:10%">
    <img src="1-Level-Up1.jpg" style="width:10%">
  </div>
</div>

</body>
</html>
